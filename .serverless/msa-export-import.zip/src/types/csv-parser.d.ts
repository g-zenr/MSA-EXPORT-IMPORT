declare module "csv-parser" {
  const csvParser: any;
  export default csvParser;
}
